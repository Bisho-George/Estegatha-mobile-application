class PersonalInfoModel {
  String? firstName;
  String? lastName;
  DateTime? birthday;
  String? phoneNumber;

  PersonalInfoModel({
    this.firstName,
    this.lastName,
    this.birthday,
    this.phoneNumber,
  });
}
